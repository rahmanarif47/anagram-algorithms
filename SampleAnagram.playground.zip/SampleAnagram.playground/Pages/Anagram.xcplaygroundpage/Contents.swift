// source from 
let firstWord = "swift"
let secondWord = "fiwts"

func isAnagram(word word: String, isAnagramOf word2: String) -> Bool {
    guard
        let word1Dictionary = countChars(word: word),
        let word2Dictionary = countChars(word: word2) else {
            return false
    }
    
    for (k, v) in word1Dictionary {
        guard v == word2Dictionary[k] else {
            return false
        }
    }
    return true
}

func countChars(word: String?) -> [Character: Int]? {
    guard let word = word, word != "" else {
        return nil
    }
    var dictionary = [Character: Int]()
    
    for char in word.sorted() {
        if let currentValue = dictionary[char] {
            dictionary.updateValue(currentValue + 1, forKey: char)
        } else {
            dictionary[char] = 1
        }
    }
    return dictionary
}

isAnagram(word: firstWord, isAnagramOf: secondWord)
